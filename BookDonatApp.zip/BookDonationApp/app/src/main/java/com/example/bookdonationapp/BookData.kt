package com.example.bookdonationapp

data class BookData(var bookImage : Int, var bookGrade : String, var bookName : String, var bookCount : Int)
