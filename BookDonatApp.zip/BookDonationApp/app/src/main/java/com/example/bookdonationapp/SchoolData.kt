package com.example.bookdonationapp

data class SchoolData(var titleImage : Int, var sclName : String, var sclAddress : String, var sclMilage : String)

