// File: QRCodeData.kt
package com.example.bookdonationapp

data class QRCodeData(
    val schoolName: String,
    val bookGrade: String,
    val bookName: String,
    val orderId: String
)
