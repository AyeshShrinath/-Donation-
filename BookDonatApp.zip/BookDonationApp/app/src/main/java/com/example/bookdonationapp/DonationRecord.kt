package com.example.bookdonationapp

data class DonationRecord(
    val bookName: String,
    val schoolName: String,
    val date: String,
    val qrCodeImage: String
)